package com.example.demo;

import org.springframework.stereotype.Component;

@Component

public class Employee {

	public Employee() {
		System.out.println("This is Employee constructore");
	}
	 void empMethod() {
		System.out.println("Employee method");
		
	
	}
	
}
